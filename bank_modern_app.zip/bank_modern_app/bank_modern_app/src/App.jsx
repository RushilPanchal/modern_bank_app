import React from 'react'

const App = () =>  (
  <div className="bg-primary w-full overflow-hidden">
    <h1>Hello, World!</h1>
  </div>
)


export default App